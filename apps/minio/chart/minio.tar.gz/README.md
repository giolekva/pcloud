# Object Store

Minio based S3 compatible object store