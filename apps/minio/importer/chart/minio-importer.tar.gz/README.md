# Minio object to knowledge graph importer

Listens to Minio bucket notifications and imports new objects into knowledge graph.