# Random puppy picture generator

Renders random puppy pictures fetched from https://dog.ceo/api