# Face detector

Provides MTCNN and Haar cascade based face detection capabilities