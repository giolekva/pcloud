Soft-Serve with TCP ingress
