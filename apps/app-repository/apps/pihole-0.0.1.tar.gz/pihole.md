Installs pihole at https://{{ .Values.Subdomain }}.{{ .Global.PrivateDomain }}
