Installs vaultwarden on private network accessible at https://{{ .Values.Subdomain }}.{{ .Global.PrivateDomain }}
